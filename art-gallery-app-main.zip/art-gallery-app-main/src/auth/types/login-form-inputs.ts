export interface LoginFormInputs {
  email: string;
  password: string;
}
