export interface ProjectState {
  id: string;
  title?: string;
  body?: string;
  date: number;
  imagesUrls: string[];
}
