export interface RegisterFormInputs {
  email: string;
  fullName: string;
  password: string;
}
