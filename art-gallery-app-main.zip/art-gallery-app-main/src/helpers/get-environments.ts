export const getEnvironments = (): ImportMetaEnv => {
  return {
    ...import.meta.env,
  };
};
